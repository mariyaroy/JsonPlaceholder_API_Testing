package com.ust.JsonPlaceholder.endpoints;

//--------------------API ENDPOINTS--------------------//

public class Routes {
	
	public static String BASEURI = "https://jsonplaceholder.typicode.com/";
	
	public static String GETSINGLERESOURCE = "posts/{id}";
	public static String GETALLRESOURCES = "posts";
	public static String CREATERESOURCE = "posts";
	public static String UPDATERESOURCE = "posts/{id}";
	public static String PATCHRESOURCE = "posts/{id}";
	public static String DELETERESOURCE = "posts/{id}";
	
	public static String FILTERRESOURCES = "posts?userId={id}";
	
	public static String SCHEMAVALIDATIONURL = "https://jsonplaceholder.typicode.com/posts/1";
	public static String SCHEMAPATH = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\schema.json";

}
