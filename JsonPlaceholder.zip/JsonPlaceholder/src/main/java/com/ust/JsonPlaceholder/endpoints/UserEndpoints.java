package com.ust.JsonPlaceholder.endpoints;

import com.ust.JsonPlaceholder.payload.UserModel;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

//--------------------ENPOINTS IMPLEMENTATION--------------------//

public class UserEndpoints {

	//GET METHOD: Getting Single Resource
	public static Response getSingleResource(int id) {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.GETSINGLERESOURCE)
				.pathParam("id", id)
				.when()
				.get();
		return response;	
	}

	//GET METHOD: Getting all resources		
	public static Response getAllResources() {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.GETALLRESOURCES)
				.when()
				.get();
		return response;	
	}

	//POST METHOD: Create a resource
	public static Response createResource(UserModel payload) {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.CREATERESOURCE)
				.body(payload)
				.when()
				.post();
		return response;	
	}

	//PUT METHOD: Update resources		
	public static Response updateResource(int id, UserModel payload) {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.UPDATERESOURCE)
				.pathParam("id",id)
				.body(payload)
				.when()
				.put();
		return response;					
	}

	//PATCH METHOD: Patching a resource	
	public static Response patchingResource(int id, UserModel payload) {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.PATCHRESOURCE)
				.pathParam("id",id)
				.body(payload)
				.when()
				.patch();
		return response;				
	}

	//DELETE METHOD: Delete a resource		
	public static Response deleteResource(int id) {
		Response response = RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.DELETERESOURCE)
				.pathParam("id",id)
				.when()
				.delete();
		return response;
	}

	//GET METHOD: Filtering resources		
	public static Response filteringResources(int userId)
	{
		Response response=RestAssured.given()
				.headers("Content-Type", ContentType.JSON,
						"Accept", ContentType.JSON)
				.baseUri(Routes.BASEURI)
				.basePath(Routes.FILTERRESOURCES)
				.queryParam("userId", userId)
				.when()
				.get();
		return response;	
	}

}
