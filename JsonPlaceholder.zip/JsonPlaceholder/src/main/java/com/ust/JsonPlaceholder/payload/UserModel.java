package com.ust.JsonPlaceholder.payload;

//--------------------PAYLOAD IMPLEMENTATION--------------------//

public class UserModel {
	
	private int id;
	private String title;
	private String body;
	private int userId;
	
	// toString() METHOD FOR CONVERSION
	@Override
	public String toString() {
		return "UserModel [id=" + id + ", title=" + title + ", body=" + body + ", userId=" + userId + ", getId()="
				+ getId() + ", getTitle()=" + getTitle() + ", getBody()=" + getBody() + ", getUserId()=" + getUserId()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
		
	// CONSTRUCTOR FROM SUPER CLASS
	public UserModel() {
		super();
	}
	
	// CONSTRUCTOR USING FIELDS
	
	public UserModel(String title) {
		super();
		this.title = title;
	}
	
	public UserModel(String title, String body, int userId) {
		super();
		this.title = title;
		this.body = body;
		this.userId = userId;
	}
	
	public UserModel(int id, String title, String body, int userId) {
		super();
		this.id = id;
		this.title = title;
		this.body = body;
		this.userId = userId;
	}
	
	// GETTERS AND SETTERS
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	} 
	
	
}
