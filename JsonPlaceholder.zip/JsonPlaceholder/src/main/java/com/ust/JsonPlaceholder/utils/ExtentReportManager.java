package com.ust.JsonPlaceholder.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

//--------------------EXTENT REPORT MANAGER IMPLEMENTATION--------------------//

public class ExtentReportManager {
	
	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;

	public static ExtentReports createInstance() {
		try {
			String repname = "TestReport-" + getTimeStamp() + ".html";
			htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "//Reports//" + repname);

			htmlReporter.config().setDocumentTitle("Extent Report");
			htmlReporter.config().setReportName("Test Report");
			htmlReporter.config().setTimelineEnabled(true);
			htmlReporter.config().setTheme(Theme.DARK);
			htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");

			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("OS", "Windows");
			extent.setSystemInfo("Host Name", "localhost");
			extent.setSystemInfo("Environment", "QA");
			extent.setSystemInfo("Username", "Team 6");
		}
		catch(Exception e) {
		      System.err.println("Error creating extent report: " + e.getMessage());
		      e.printStackTrace();
		}
		return extent;
	}
	
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

}
