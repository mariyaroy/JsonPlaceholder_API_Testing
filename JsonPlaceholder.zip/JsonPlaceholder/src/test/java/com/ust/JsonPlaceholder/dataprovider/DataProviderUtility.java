package com.ust.JsonPlaceholder.dataprovider;

import org.testng.annotations.DataProvider;
import com.ust.JsonPlaceholder.utils.ExcelReader;

public class DataProviderUtility {
	
	@DataProvider(name = "ExcelData")
	public String[][] getData() {
		String PATH = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\DataSet.xlsx";
		String name = "json";
		return ExcelReader.getExcelData(PATH, name);
	}
  
}
