package com.ust.JsonPlaceholder.karatetests;

import com.intuit.karate.junit5.Karate;

public class KarateRunner {
	
	@Karate.Test
	public Karate runTest() {
		//return Karate.run("jsonplaceholder.feature").relativeTo(getClass());
		return Karate.run().tags("@jsonplaceholder").relativeTo(getClass());
	}

}
