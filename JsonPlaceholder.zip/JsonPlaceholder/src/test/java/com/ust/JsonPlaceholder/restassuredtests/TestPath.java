package com.ust.JsonPlaceholder.restassuredtests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.JsonPlaceholder.dataprovider.DataProviderUtility;
import com.ust.JsonPlaceholder.endpoints.Routes;
import com.ust.JsonPlaceholder.endpoints.UserEndpoints;
import com.ust.JsonPlaceholder.payload.UserModel;
import com.ust.JsonPlaceholder.testlistener.ExtentReportListener;

import io.restassured.RestAssured;
import io.restassured.response.Response;

@Listeners(ExtentReportListener.class)
public class TestPath {
	
	UserModel payload;
	
	@BeforeClass
	public void setup() {
		RestAssured.useRelaxedHTTPSValidation(); // IGNORE SSL CERTIFICATION VALIDATION
		payload = new UserModel(1, "foo", "bar", 1); // INITIALIZE PAYLOAD
	}

	@Test (priority = 1, description = "Validate getting a single resource")
	public void getSingleResource() {
		Response response = UserEndpoints.getSingleResource(payload.getId());
		response.then().log().all(); // LOG RESPONSE DETAILS
		response.then().assertThat()
		.body("userId", equalTo(1)); // ASSERTING BODY CONTENT
		assertEquals(response.statusCode(), 200); // STATUS CODE VALIDATION
	}

	@Test(priority = 2, description = "Validate getting all resources")
	public void getAllResources() {
		Response response = UserEndpoints.getAllResources();
		response.then().log().all();
		response.then().assertThat()
		.body("[0].title", equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit"));
		assertEquals(response.statusCode(), 200);
	}

	@Test(priority = 3, description = "Validate creating a resource")
	public void createResource() {
		UserModel createPayload = new UserModel("foo", "bar", 1);
		Response response = UserEndpoints.createResource(createPayload);
		response.then().log().all();
		response.then().assertThat()
		.body("id", equalTo(101));
		assertEquals(response.statusCode(), 201);
	}

	@Test(priority = 4, description = "Validate updating a resource")
	public void updateResource() {
		Response response = UserEndpoints.updateResource(payload.getId(), payload);
		response.then().log().all();
		response.then().assertThat()
		.body("title", equalTo("foo"));
		assertEquals(response.statusCode(), 200);
	}

	@Test(priority = 5, description = "Validate patching a resource")
	public void patchResource() {
		UserModel patchPayload = new UserModel("foo");
		Response response = UserEndpoints.patchingResource(payload.getId(), patchPayload);
		response.then().log().all();
		response.then().assertThat()
		.body("title", equalTo("foo"));
		assertEquals(response.statusCode(), 200);
	}

	@Test(priority = 6, description = "Validate deleting a resource")
	public void deleteResources() {
		Response response = UserEndpoints.deleteResource(payload.getId());
		response.then().log().all();
		assertEquals(response.statusCode(), 200);
	}

	@Test(priority = 7, description = "Validate filtering resources")
	public void filterResources() {
		Response response = UserEndpoints.filteringResources(payload.getUserId());
		response.then().log().all();
		assertEquals(response.statusCode(), 200);
	}

	@Test(priority = 8, description = "Validate JSON schema of a response")
	public void schemaValidations() {
		RestAssured.given().baseUri(Routes.SCHEMAVALIDATIONURL)
		.when()
		.get()
		.then()
		.assertThat()
		.body(matchesJsonSchema(new File(Routes.SCHEMAPATH)));			
	}
	
	// VALIDATE CREATING A RESOURCE USING DATA FROM A DATAPROVIDER
	@Test(priority = 9, dataProvider = "ExcelData", dataProviderClass = DataProviderUtility.class)
	public void createResourcesDataprovider(String title, String body, String userId) {
		UserModel dataPayload = new UserModel();
		dataPayload.setTitle(title);
		dataPayload.setBody(body);
		dataPayload.setUserId(Integer.parseInt(userId));
		
		Response response = UserEndpoints.createResource(dataPayload);
		response.then().log().all();
		response.then().assertThat()
		.body("id", equalTo(101))
		.body("title", equalTo("foo"));
		assertEquals(response.statusCode(), 201);
	}


}
